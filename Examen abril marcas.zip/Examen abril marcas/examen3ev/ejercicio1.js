const titulo=document.getElementById("enunciado")
titulo.addEventListener(onclick,cambiar())

function generarNumeros(num1,num2){

    resultado = document.getElementById("numeros")
    let numeros=""
    
    enunciado=document.getElementById("enunciado")

    if(num1>num2){
            let temp=num2;
            num2=num1
            num1=temp
    }

    for(let i=0; i<10; i++){
        let ale=Math.floor(Math.random() *(num1+1) )+(num2-num1)

        numeros += ale +", " 

    }
    enunciado.innerHTML="Diez números entre " + num1 + " y " +num2 + "</br>"
    /*for(let i=0;i<numeros.length;i++){
        if(numeros[i]%2==0){
            numero[i].style.color="blue"
        }
        else{ 
            numero[i].style.color="red"
            numero[i].style.border="2px solid black"

        }
    }*/
    resultado.innerHTML=numeros
    



}
generarNumeros(10,50)//aqui se pasan los numeros como argumentos

function cambiar(){
    
    
    
}





