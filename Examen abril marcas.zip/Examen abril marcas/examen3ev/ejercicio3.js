function cambio(){
    const euros=document.getElementById("euros").value
    const pesetas = document.getElementById("pesetas").value
    const boton = document.getElementById("enviar")
    let calculo=(euros*166.386).toFixed(3)

    
    if(calculo==pesetas){
        boton.disabled = false
        return true

    }
    else if(euros==0 && pesetas == 0){
        boton.disabled=false
        return true
    }
    else{
        boton.disabled=true
        return false
    }
}