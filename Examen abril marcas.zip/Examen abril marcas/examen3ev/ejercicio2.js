function cambiar(elemento){
    if(elemento.className=="azul"){
        elemento.className="rojo"
    }
    else{
        elemento.className="azul"

    }
    

}