const numero = parseInt(prompt('Por favor, introduce un número:'));
if (isNaN(numero)) {
    alert('Por favor, introduce un número válido.');
} else if (numero % 2 === 0) {
    alert('El número es par.');
} else {
    alert('El número es impar.');
}