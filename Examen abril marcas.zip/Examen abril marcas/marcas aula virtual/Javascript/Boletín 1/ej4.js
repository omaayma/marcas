function generarDivisibles() {
    let resultado = '';
    for (let i = 7; i < 10000; i += 7) {
        resultado += i + '<br>';
    }
    document.getElementById('resultado').innerHTML = resultado;
}