let numeros = [];
for (let i = 0; i < 6; i++) {
    let aleatorio = Math.floor(Math.random() * 49) + 1;
    numeros[i] = aleatorio; 
}
document.write('Números generados: ' + numeros.join(', '));