const numero = parseInt(prompt('Por favor, introduce un número:'));
if (isNaN(numero)) {
    alert('Por favor, introduce un número válido.');
} else if (numero % 3 === 0) {
    alert('El número es divisible por 3.');
} else {
    alert('El número no es divisible por 3.');
}
