let dado1 = Math.floor(Math.random() * 6) + 1; 
let dado2 = Math.floor(Math.random() * 6) + 1; 
document.getElementById('aleatorio').innerHTML = 'Dado 1: ' + dado1 + " y " + " Dado 2: " + dado2;