let numero = Math.floor(Math.random() * 51); 
document.getElementById('numeroAleatorio').innerHTML = 'Número Aleatorio: ' + numero;
