let numero = parseInt(prompt('Introduce un número:'));

if (isNaN(numero) || numero <= 1) {
    alert('Por favor, introduce un número válido mayor que 1.');
} else {
    let esPrimo = true;
for (let i = 2; i < numero; i++) { 
    if (numero % i === 0) {
        esPrimo = false;
        break;
    }
}
    if (esPrimo) {
        alert('El número ' + numero + ' es primo.');
    } else {
        alert('El número ' + numero + ' no es primo.');
    }
}