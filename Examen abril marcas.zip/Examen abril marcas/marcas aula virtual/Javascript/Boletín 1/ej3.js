function generarMultiplos() {
    let numero = document.getElementById('numero').value;
    let resultado = '';
    for (let i = 1; i <= 5; i++) {
        resultado += (numero * i) + '<br>';
    }
    document.getElementById('resultado').innerHTML = resultado;
}