let quiniela = '';
for (let i = 0; i < 15; i++) {
    let aleatorio = Math.floor(Math.random() * 3) + 1; 
    if (aleatorio === 3) {
        quiniela += 'X '; 
    } else {
        quiniela += aleatorio + ' '; 
    }
}
document.write('Resultados de la quiniela: ' + quiniela.trim());