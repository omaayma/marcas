const numerosPares = document.getElementById('numerosPares');
for (let i = 1; i <= 50; i++) {
    numerosPares.innerHTML += (i * 2) + '<br>';
}