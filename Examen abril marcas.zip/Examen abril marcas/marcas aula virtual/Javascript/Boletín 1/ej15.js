let numero;
do {
    numero = Math.floor(Math.random() * 1000) + 1; 
    document.write(numero + '<br>'); 
} while (numero !== 666); 
document.write('Se ha generado el 666. El programa ha terminado.');