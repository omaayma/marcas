let num1 = parseInt(prompt('Introduce el primer número:'));
let num2 = parseInt(prompt('Introduce el segundo número:'));

if (isNaN(num1) || isNaN(num2)) {
    document.write('Por favor, introduce números válidos.');
} else {
    let min = Math.min(num1, num2);
    let max = Math.max(num1, num2);

    let aleatorio = Math.floor(Math.random() * (max - min + 1)) + min;
    document.write('Número aleatorio entre ' + min + ' y ' + max + ': ' + aleatorio);
}