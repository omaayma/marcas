let precio = parseFloat(prompt('Introduce el precio del artículo:'));
if (isNaN(precio) || precio <= 0) {
    alert('Por favor, introduce un precio válido.');
} else {
    let total = precio * 1.21;
    alert('El precio con IVA incluido es: ' + total.toFixed(2) + ' €');
}