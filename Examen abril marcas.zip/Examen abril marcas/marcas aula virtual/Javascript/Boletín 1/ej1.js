const listaNumeros = document.getElementById('listaNumeros');
for (let i = 1; i <= 10; i++) {
    listaNumeros.innerHTML += i + '<br>';
}

