let num1 = parseInt(prompt('Introduce el primer número:'));
let num2 = parseInt(prompt('Introduce el segundo número:'));

if (isNaN(num1) || isNaN(num2)) {
    document.write('Por favor, introduce números válidos.');
} else {
    let aleatorio = Math.floor(Math.random() * (num2 - num1 + 1)) + num1;
    document.write('Número aleatorio entre ' + num1 + ' y ' + num2 + ': ' + aleatorio);
}