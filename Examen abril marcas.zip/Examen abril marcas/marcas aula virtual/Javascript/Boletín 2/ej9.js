function calcularPagoMensual(importe, meses) {
    return importe / meses; 
}
let importe = parseFloat(prompt('Introduce el importe total en euros:'));

let meses = parseInt(prompt('Introduce el número de meses para pagar:'));

if (isNaN(importe) || isNaN(meses) || importe <= 0 || meses <= 0) {
    document.write('Por favor, introduce valores válidos.');
} else {
    let pagoMensual = calcularPagoMensual(importe, meses);
    
    document.write('El importe mensual a pagar es: ' + pagoMensual.toFixed(2) + ' €');
}