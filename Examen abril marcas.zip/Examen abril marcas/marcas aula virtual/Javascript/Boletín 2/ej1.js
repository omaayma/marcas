let vector = [];
for (let i = 0; i < 100; i++) {
    vector[i] = Math.floor(Math.random() * 1000) + 1; 
}

document.write('Números mayores o iguales a 500:<br>');
for (let i = 0; i < vector.length; i++) {
    if (vector[i] >= 500) {
        document.write(vector[i] + '<br>');
    }
}