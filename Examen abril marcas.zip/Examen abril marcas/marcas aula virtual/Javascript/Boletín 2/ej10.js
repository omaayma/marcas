let texto = prompt('Introduce una cadena de texto:');

let resultado = eliminarVocales(texto);

function eliminarVocales(texto) {
    let textoSinVocales = '';
    for (let i = 0; i < texto.length; i++) {
        if (!'aeiouAEIOU'.includes(texto[i])) { 
            textoSinVocales += texto[i];
        }
    }
    return textoSinVocales;
}
document.write('Texto original: ' + texto + '<br>');
document.write('Texto sin vocales: ' + resultado);