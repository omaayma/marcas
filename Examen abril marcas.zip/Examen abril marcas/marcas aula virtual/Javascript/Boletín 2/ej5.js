let texto = prompt('Introduce una cadena de texto:');
let textoHacker = '';

for (let i = 0; i < texto.length; i++) {
    let caracter = texto[i];
    if (caracter === 'a' || caracter === 'A') {
        textoHacker += '4';
    } else if (caracter === 'e' || caracter === 'E') {
        textoHacker += '3';
    } else if (caracter === 'i' || caracter === 'I') {
        textoHacker += '1';
    } else if (caracter === 'o' || caracter === 'O') {
        textoHacker += '0';
    } else {
        textoHacker += caracter;
    }
}
document.write('Texto original: ' + texto + '<br>');
document.write('Texto en alfabeto hacker: ' + textoHacker);