let texto = prompt('Introduce una cadena de texto:');
let textoReverso = '';
for (let i = texto.length - 1; i >= 0; i--) {
    textoReverso += texto[i];
}
document.write('Texto original: ' + texto + '<br>');
document.write('Texto al revés: ' + textoReverso);