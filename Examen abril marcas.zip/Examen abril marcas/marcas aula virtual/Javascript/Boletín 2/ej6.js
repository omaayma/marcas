let vector = [];
for (let i = 0; i < 100; i++) {
    vector[i] = Math.floor(Math.random() * 1000) + 1;
}
let mayor = vector[0];
let menor = vector[0];
document.write('Números mayores o iguales a 500:<br>');
for (let i = 0; i < vector.length; i++) {
    if (vector[i] >= 500) {
        document.write(vector[i] + '<br>');
    }
    if (vector[i] > mayor) {
        mayor = vector[i];
    }
    if (vector[i] < menor) {
        menor = vector[i];
    }
}
document.write('<br>El número mayor es: ' + mayor + '<br>');
document.write('El número menor es: ' + menor);