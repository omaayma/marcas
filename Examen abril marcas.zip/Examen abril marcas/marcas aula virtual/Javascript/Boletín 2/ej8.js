function mayorDeCuatro(num1, num2, num3, num4) {
    return Math.max(num1, num2, num3, num4); 
}

let num1 = parseInt(prompt('Introduce el primer número:'));
let num2 = parseInt(prompt('Introduce el segundo número:'));
let num3 = parseInt(prompt('Introduce el tercer número:'));
let num4 = parseInt(prompt('Introduce el cuarto número:'));

let resultado = mayorDeCuatro(num1, num2, num3, num4);

document.write('El mayor de los números es: ' + resultado);