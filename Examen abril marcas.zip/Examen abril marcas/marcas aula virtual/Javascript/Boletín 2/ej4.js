let texto = prompt('Introduce una cadena de texto:');
let pares = '';
let impares = '';

for (let i = 0; i < texto.length; i++) {
    if (i % 2 === 0) { 
        pares += texto[i];
    } else { 
        impares += texto[i];
    }
}

document.write('Texto original: ' + texto + '<br>');
document.write('Letras en posiciones pares: ' + pares + '<br>');
document.write('Letras en posiciones impares: ' + impares);