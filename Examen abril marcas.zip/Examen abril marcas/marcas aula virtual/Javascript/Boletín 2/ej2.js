let texto = prompt('Introduce una cadena de texto:');
let textoSinEspacios = '';
let espaciosEliminados = 0;
for (let i = 0; i < texto.length; i++) {
    if (texto[i] !== ' ') {
        textoSinEspacios += texto[i];
    } else {
        espaciosEliminados++;
    }
}
document.write('Texto sin espacios: ' + textoSinEspacios + '<br>');
document.write('Número de espacios eliminados: ' + espaciosEliminados);