function escribirFantasmal() {
    let caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    let parrafo = document.getElementById('fantasma');

    parrafo.textContent += caracteres[Math.floor(Math.random() * caracteres.length)];
}
/*function escribirFantasmal() {
    let caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let parrafo = document.getElementById('fantasma');
    let caracterAleatorio = caracteres[Math.floor(Math.random() * caracteres.length)];
    
    let nodoTexto = document.createTextNode(caracterAleatorio); // Crear un nodo de texto
    parrafo.appendChild(nodoTexto); // Agregar el carácter al párrafo
} esta forma es de chatgpt que dice que lo añade al final del parrafo dejando el original*/