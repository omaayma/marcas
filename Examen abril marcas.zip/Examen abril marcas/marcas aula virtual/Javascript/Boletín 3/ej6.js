function generarNumeroAleatorio() {
    return Math.floor(Math.random() * 10) + 1; 
}

function actualizarNumero() {
    let titular = document.getElementById('titular');
    let numeroActual = parseInt(titular.textContent) || 0; 
    let nuevoNumero = generarNumeroAleatorio();
    let suma = numeroActual + nuevoNumero;

    if (suma > 500) {
        suma = 0; 
    }

    titular.textContent = suma; 
}

let titular = document.getElementById('titular');
titular.textContent = generarNumeroAleatorio();