function generarNumeroAleatorio() {
    return Math.floor(Math.random() * 10) + 1;  
}

function generarNuevoNumero() {
    let numero = document.getElementById('numero');
    numero.textContent = generarNumeroAleatorio(); 
}

function elevarAlCuadrado() {
    let numero = document.getElementById('numero');
    let valorActual = parseInt(numero.textContent); 
    numero.textContent = (valorActual * valorActual) + 1;
}


document.getElementById('numero').textContent = generarNumeroAleatorio();

document.getElementById('numero').addEventListener('dblclick', elevarAlCuadrado);
document.querySelector('h1').addEventListener('mouseover', generarNuevoNumero);