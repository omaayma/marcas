function barajarTextos() {
    let parrafos = document.querySelectorAll('p'); 

    let textos = [
        parrafos[0].textContent,
        parrafos[1].textContent,
        parrafos[2].textContent,
        parrafos[3].textContent
    ];

    textos.sort(() => Math.random() - 0.5);
    
    parrafos[0].textContent = textos[0];
    parrafos[1].textContent = textos[1];
    parrafos[2].textContent = textos[2];
    parrafos[3].textContent = textos[3];
}