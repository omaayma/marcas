function alternarTexto(elemento) {
    if (elemento.textContent === 'Abierto') {
        elemento.textContent = 'Cerrado';
    } else {
        elemento.textContent = 'Abierto';
    }
}