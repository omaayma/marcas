let numeroSorteo = Math.floor(Math.random() * 9999) + 1; 

alert('Tu número de participación en el sorteo es: ' + numeroSorteo);