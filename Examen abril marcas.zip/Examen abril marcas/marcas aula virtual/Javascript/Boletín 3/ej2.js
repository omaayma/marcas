function generarNumero() {
    let numeroAleatorio = Math.floor(Math.random() * 100) + 1; 
    let parrafo = document.createElement('p'); 

    parrafo.textContent = 'Número generado: ' + numeroAleatorio; 

    document.body.appendChild(parrafo); 
}