let contador = 0;

function manejarDobleClick() {
    let parrafos = document.querySelectorAll('p');

    if (contador < parrafos.length) {
        parrafos[contador].style.visibility = 'hidden';
        contador++;
    } else {
        for (let i = 0; i < parrafos.length; i++) {
            parrafos[i].style.visibility = 'visible'; 
        }
        contador = 0;
    }
}