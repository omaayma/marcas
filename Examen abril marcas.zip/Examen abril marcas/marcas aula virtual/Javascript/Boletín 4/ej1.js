function cambiarColorFondo() {
    if (window.innerWidth > 500) {
        document.body.style.backgroundColor = 'green'; 
    } else {
        document.body.style.backgroundColor = 'red'; 
    }
}

cambiarColorFondo();
window.addEventListener('resize', cambiarColorFondo);

/*function cambiarColorFondo() {
    if (window.innerWidth > 500) {
        document.body.classList.add('mayor');
        document.body.classList.remove('menor');
    } else {
        document.body.classList.add('menor');
        document.body.classList.remove('mayor');
    }
}

cambiarColorFondo();
window.addEventListener('resize', cambiarColorFondo);
se hace así si queremos usar el css aparte */