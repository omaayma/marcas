let esVerde = false; 
function alternarColor() {
    if (esVerde) {
        document.body.classList.remove('verde');
        document.body.classList.add('rojo');
    } else {
        document.body.classList.remove('rojo');
        document.body.classList.add('verde');
    }
    esVerde = !esVerde; 
}

document.getElementById('boton').addEventListener('click', alternarColor);