document.getElementById('boton-anadir').addEventListener('click', function() {
    let nuevaTarea = prompt('Introduce una nueva tarea:');
    if (nuevaTarea) {
        let lista = document.getElementById('lista-tareas');
        let elemento = document.createElement('li');
        elemento.textContent = nuevaTarea;
        lista.appendChild(elemento);
    }
});