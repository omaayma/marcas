
let escala = 1;

function duplicarTamaño() {
    let imagen = document.getElementById('imagen');
    let anchoVentana = window.innerWidth;
    let altoVentana = window.innerHeight;

    let nuevoAncho = imagen.width * 2;
    let nuevoAlto = imagen.height * 2;

    if (nuevoAncho <= anchoVentana && nuevoAlto <= altoVentana) {
        escala *= 2; 
        imagen.style.width = nuevoAncho + 'px';
        imagen.style.height = nuevoAlto + 'px';
    }
}

function restaurarTamaño() {
    let imagen = document.getElementById('imagen');
    escala = 1; 
    imagen.style.width = '';
    imagen.style.height = '';
}

let imagen = document.getElementById('imagen');
imagen.addEventListener('click', duplicarTamaño);
imagen.addEventListener('dblclick', restaurarTamaño);