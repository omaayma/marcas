function tirarDado() {
    return Math.floor(Math.random() * 6) + 1;
  }
function lanzarDados() {
    let lanzamientos = 0;
    let dados;
    do {
      dados = [tirarDado(), tirarDado(), tirarDado()];
      lanzamientos++;
      document.getElementById("resultado").innerHTML += dados.join(' - ') + '<br>';
    } while (dados[0] !== dados[1] || dados[1] !== dados[2]);

   document.getElementById("resultado").innerHTML += "<br>He tenido que lanzar los dados" + " " + lanzamientos + " " + "veces para que todos sean iguales";
}