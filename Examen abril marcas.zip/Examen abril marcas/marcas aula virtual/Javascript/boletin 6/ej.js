function moverTexto(origen) {
    const textoVerde = document.getElementById("textoVerde");
    const textoRojo = document.getElementById("textoRojo");

    if (origen === "verde") {
        textoRojo.textContent = textoVerde.textContent; // Mover texto de verde a rojo
        textoVerde.textContent = "Hemos hecho doble clic"; // Cambiar texto en verde
    } else if (origen === "roja") {
        textoVerde.textContent = textoRojo.textContent; // Mover texto de rojo a verde
        textoRojo.textContent = "Hemos hecho doble clic"; // Cambiar texto en rojo
    }
}