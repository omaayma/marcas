function tirarDado() {
    // Generar un número aleatorio entre 1 y 9
    let random = Math.floor(Math.random() * 9) + 1;

    // Asignar el número 6 tres veces más probabilidades
    if (random <= 3) return 6; // 1, 2, 3 -> Número 6
    return random - 3; // 4, 5, 6 -> Números 1, 2, 3, 4, 5
}

function lanzarDados() {
    let lanzamientos = 0;
    let dados;
    let contador = [0, 0, 0, 0, 0, 0]; // Contador para cada número (1 a 6)
    document.getElementById("resultado").innerHTML = ""; // Limpiar resultados previos

    do {
        dados = [tirarDado(), tirarDado(), tirarDado()];

        // Incrementar el contador para cada número que aparece
        dados.forEach(dado => contador[dado - 1]++);

        lanzamientos++;
        document.getElementById("resultado").innerHTML += dados.join(' - ') + '<br>';
    } while (dados[0] !== dados[1] || dados[1] !== dados[2]);

    document.getElementById("resultado").innerHTML += "<br>He tenido que lanzar los dados " + lanzamientos + " veces para que todos sean iguales.<br><br>";

    for (let i = 0; i < 6; i++) {
        let porcentaje = ((contador[i] / (lanzamientos * 3)) * 100).toFixed(2); // Porcentaje con 2 decimales
        document.getElementById("resultado").innerHTML += "El número " + (i + 1) + " ha salido el " + porcentaje + " % de las veces<br>";
    }
}