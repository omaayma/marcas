function validar() {
    const numero1 = parseInt(document.getElementById('numero1').value);
    const numero2 = parseInt(document.getElementById('numero2').value);
    const botonEnviar = document.getElementById('enviar');

    if (isNaN(numero1) || isNaN(numero2)) {
        botonEnviar.disabled = true;
        return;
    }

    if (numero1 !== numero2) {
        botonEnviar.disabled = true; 
        return;
    }
    if (numero1 < 9 || numero1 > 160 || numero2 < 9 || numero2 > 160) {
        botonEnviar.disabled = true; 
    }

    botonEnviar.disabled = false;
}

function limpiar() {
    document.getElementById('numero1').value = '';
    document.getElementById('numero2').value = '';
    document.getElementById('enviar').disabled = true;
}