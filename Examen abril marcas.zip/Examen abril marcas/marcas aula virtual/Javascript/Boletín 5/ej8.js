
function actualizarContadores(textarea) {
    let escritos = textarea.value.length; 
    let restantes = 140 - escritos; 


    textarea.form.escritos.value = escritos;
    textarea.form.restantes.value = restantes;
}


function habilitar(checkbox) {
    let botonEnviar = checkbox.form.enviar;
    botonEnviar.disabled = !checkbox.checked; 
}


function resetearContadores() {
    let formulario = document.querySelector('form');
    formulario.escritos.value = 0; 
    formulario.restantes.value = 140; 
}