function validarNumeros(formulario) {
    let numero1 = parseFloat(formulario.numero1.value);
    let numero2 = parseFloat(formulario.numero2.value);
    let mensajeError = document.getElementById('error');

    if (isNaN(numero1) || isNaN(numero2)) {
        mensajeError.textContent = "Error: Ambos campos deben contener números.";
        mensajeError.hidden = false;
        return false;
    }

  
    if (numero1 < 10) {
        mensajeError.textContent = "Error: El primer número no puede ser menor de 10.";
        mensajeError.hidden = false;
        return false;
    }

    if (numero2 > 500) {
        mensajeError.textContent = "Error: El segundo número no puede ser mayor de 500.";
        mensajeError.hidden = false; 
        return false;
    }

    if (numero1 >= numero2) {
        mensajeError.textContent = "Error: El primer número debe ser estrictamente menor que el segundo.";
        mensajeError.hidden = false; 
        return false;
    }

    if (numero2 > 2 * numero1) {
        mensajeError.textContent = "Error: El segundo número no puede ser más del doble del primero.";
        mensajeError.hidden = false; 
        return false;
    }
    mensajeError.hidden = true;
    alert("Formulario enviado correctamente.");
    return true;
}