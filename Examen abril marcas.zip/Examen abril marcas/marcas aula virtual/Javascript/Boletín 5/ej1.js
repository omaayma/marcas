/*si queremos mostrar lo que hemos escrito function prueba(elemento) {
    alert(elemento.value);}*/
function habilitar(check) {
    if (check.checked) {
        check.form.enviar.disabled = false; 
    } else {
        check.form.enviar.disabled = true; 
    }
}

function validar(formulario) {
    let usuario = formulario.usuario.value.trim();
    let contraseña = formulario.contraseña.value;
    let contraseña2 = formulario.contraseña2.value;
    let condiciones = formulario.condiciones.checked;

    if (usuario.includes(" ")) {
        alert('Error: el usuario no puede tener espacios en blanco.');
        return false;
    }
    if (!isNaN(usuario[0])) {
        alert('Error: el usuario no puede empezar por un número.');
        return false;
    }
    if (contraseña === "" || contraseña2 === "") {
        alert("Error: La contraseña no puede estar vacía.");
        return false;
    }
    if (contraseña !== contraseña2) {
        alert("Error: Las contraseñas no coinciden.");
        return false;
    }

    if (contraseña.startsWith(usuario)) {
        alert("Error: La contraseña no puede empezar con el nombre de usuario.");
        return false;
    }

    if (!condiciones) {
        alert("Error: Debes aceptar las condiciones.");
        return false;
    }
    alert("Formulario enviado correctamente.");
    return true;

}
