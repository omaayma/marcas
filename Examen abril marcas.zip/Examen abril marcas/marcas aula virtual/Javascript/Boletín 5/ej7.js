let numeroSecreto = Math.floor(Math.random() * 51); 
let intentos = 0;

function habilitar() {
    let checkbox = document.getElementById('condiciones');
    let boton = document.getElementById('jugar');
    boton.disabled = !checkbox.checked; 
}

document.getElementById('jugar').addEventListener('click', function() {
    let numeroUsuario = parseInt(document.getElementById('numero').value);
    let contador = document.getElementById('contador');

    if (isNaN(numeroUsuario) || numeroUsuario < 0 || numeroUsuario > 50) {
        alert("Por favor, introduce un número válido entre 0 y 50.");
        return;
    }

    intentos++;
    contador.value = intentos; 

    if (numeroUsuario === numeroSecreto) {
        alert("¡Has acertado! El número era " + numeroSecreto);
        numeroSecreto = Math.floor(Math.random() * 51); 
        
        intentos = 0; 
        contador.value = intentos;
    } else if (numeroUsuario < numeroSecreto) {
        alert("El número secreto es mayor que " + numeroUsuario);
    } else {
        alert("El número secreto es menor que " + numeroUsuario);
    }
});