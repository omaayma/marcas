function validarNumeros(formulario) {
    let numero1 = formulario.numero1.value.trim();
    let numero2 = formulario.numero2.value.trim();

    if (numero1 === "" || numero2 === "") {
        alert("Error: Ninguno de los campos puede estar vacío.");
        return false;
    }
    numero1 = parseFloat(numero1);
    numero2 = parseFloat(numero2);
    
    if (numero1 >= numero2) {
        alert("Error: El primer número debe ser estrictamente menor que el segundo.");
        return false;
    }

    alert("Formulario enviado correctamente.");
    return true;
}