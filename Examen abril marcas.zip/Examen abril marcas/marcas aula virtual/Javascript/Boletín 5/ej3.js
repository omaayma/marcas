function habilitar(checkbox) {
    let boton = document.getElementById('enviar');
    boton.disabled = !checkbox.checked; 
}

function validar(formulario) {
    let comentarios = formulario.comentarios.value.trim();
    if (comentarios === "") {
        alert("Error: El campo de comentarios no puede estar vacío.");
        return false;
    }
    alert("Formulario enviado correctamente.");
    return true;
}
