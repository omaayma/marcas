let captcha;

function generarCaptcha() {
    captcha = Math.floor(100000 + Math.random() * 900000); 
    document.getElementById('captcha').innerText = "Captcha: " + captcha;
}

function validarCaptcha(formulario) {
    let respuesta = formulario.respuesta.value.trim();
    if (respuesta === String(captcha)) {
        alert("Captcha correcto. ¡Formulario enviado!");
        return true; 
    } else {
        alert("Captcha incorrecto. Se generará uno nuevo.");
        generarCaptcha(); 
        return false; 
    }
}

window.onload = generarCaptcha;