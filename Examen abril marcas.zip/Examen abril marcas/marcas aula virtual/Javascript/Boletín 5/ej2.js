function validar(formulario) {
    let usuario = formulario.usuario.value.trim();
    let contraseña = formulario.contraseña.value;
    let contraseña2 = formulario.contraseña2.value;
    let condiciones = formulario.condiciones.checked;

    if (usuario.includes(" ")) {
        alert('Error: el usuario no puede tener espacios en blanco.');
        return false;
    }

    if (!isNaN(usuario[0])) {
        alert('Error: el usuario no puede empezar por un número.');
        return false;
    }

    if (contraseña === "" || contraseña2 === "") {
        alert("Error: La contraseña no puede estar vacía.");
        return false;
    }

    if (contraseña !== contraseña2) {
        alert("Error: Las contraseñas no coinciden.");
        return false;
    }
    if (contraseña.startsWith(usuario)) {
        alert("Error: La contraseña no puede empezar con el nombre de usuario.");
        return false;
    }

    let tieneMinuscula = false;
    let tieneMayuscula = false;
    let tieneNumero = false;

    for (let i = 0; i < contraseña.length; i++) {
        let codigo = contraseña.charCodeAt(i);

        if (codigo >= 97 && codigo <= 122) {
            tieneMinuscula = true;
        }

        if (codigo >= 65 && codigo <= 90) {
            tieneMayuscula = true;
        }

        if (codigo >= 48 && codigo <= 57) {
            tieneNumero = true;
        }

        if (contraseña[i] === 'ñ' || contraseña[i] === 'Ñ') {
            tieneMinuscula = true; 
        }
    }

    if (!tieneMinuscula || !tieneMayuscula || !tieneNumero) {
        alert("Error: La contraseña debe tener al menos una minúscula, una mayúscula y un número.");
        return false;
    }


    if (!condiciones) {
        alert("Error: Debes aceptar las condiciones.");
        return false;
    }

    alert("Formulario enviado correctamente.");
    return true;
}